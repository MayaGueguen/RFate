library(SPOT)
######################################### FATEHD GLOBAL SENSITIVITY ANALYSIS ########################################
##### 1. Create the parameter space
######## 1.a. Global Model Thresholds
######################################################################################################
########### (The problem here is that some parameters need to be smaller than others so for it needs to be a lhs with constraint
########### which decreases the parameter space for other variables too)
############# DECISION: Checked and see that 50% is OK 

defaultglobparams = c(10000000,50000000,80000000,95000000,190000000,50000000)
names(defaultglobparams) = c("max_abund_low","max_abund_medium","max_abund_high","light_thres_medium","light_thres_low","cohort")
rangeglobparam = (defaultglobparams*50)/100
plow =defaultglobparams- rangeglobparam
phigh = defaultglobparams +rangeglobparam
paramglob = cbind(plow,phigh)

######## 1.b. Seeding parameters
######################################################################################################
######### (I will need a constraint between seeding duration and timestep)
seeding =rbind( seeding_duration=c(1,500), 
                seeding_timestep = c(1,100), 
                seeding_input = c(10,500)) 
colnames(seeding)<- c("plow","phigh")
######## 1.c. Light Related Parameters
######################################################################################################
######### DECISION: It does not really makes sense  to play with the PFGs'observed data, so we decided to play mainly with related parameters
######### DECISION: Different scenarios for attributing shade tolerance 
###################(Scenarios for shade tolerance which will define the variation
###################### because we already vary the the thresholds in global parameters.)
######### ATTENTION: These need to be done at the stage of preparing the light parameter files.
######### 1.c.i Creating the dataset for light parameters
lightparam = rbind(strata_limits = c(3,7),
                   shade_tolerance = c(1,27)) #scenario number
colnames(lightparam)<- c("plow","phigh")
######## 1.c.ii Creating the scenarios table for shade tolerance
######################################################################################################
# Germinants:    1a) tolerant to Low light
#                1b) tolerant to Medium Light
#                1c) tolerant to Medium and Low Light
# Mature Shrubs: 2a) tolerant to Low light
#                2b) tolerant to Medium Light
#                2c) tolerant to Medium and Low Light
# Mature Trees : 3a) tolerant to Low light
#                3b) tolerant to Medium Light
#                3c) tolerant to Medium and Low Light
scenarios = expand.grid(G = c("1a","1b","1c"), Cm = c("2a","2b","2c"),Pm=c("3a","3b","3c"))

######## 1.c.iii Strata limits
######################################################################################################
######### sort(all_break[i]) should be the strata.limits defined in the PRE_FATE.params_PFGlight function
########## for the corresponding simulation. 

#break_param = as.numeric(c(0,4,5,7,8,9,10,20,30,40,50,60,70)^2)
break_param = c(0,25,31,80,300,900,3600)
all_break =list()
# all_break_hist=c()
for (i in 1:length(ALLparamspace[,"strata_limits"])){
  num = ALLparamspace[i,"strata_limits"]
  all_break[[i]] <- sample(break_param,num)
  # all_break_hist<- c(all_break_hist, c(sample(break_param,num)))
}
# cutcut = cut(all_break_hist,breaks=break_param)
# barplot(table(cutcut))
# 
######## 1.c.iv CHANGING THE PRE_FATE.params_PFGlight ---> PREFATE_light_FORSA function 
######################################################################################################
########## to be able to create new height breaks.
########## AND implement the different scenarios. 
########## BEWARE: new arguments are put for the function
# numlimStrata = as the ALLparamspace[,"strata_limits"]
# all_break.list = as the break sequences that you created from the lhs strata_limits
# numscenario = the scenario number from LHS shade_tolerance
# scenariosST = scenario data frame that I created here

######## 1.d. Soil Parameters
######################################################################################################
####### 1.d.i Calculate the marginal values
######################################################################################################

# Parameter ranges for soil contribution based on PFG types. 
ar = 1
Hmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="H"),"soil_contrib"])+ar
Hmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="H"),"soil_contrib"])-ar

Cmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="C"),"soil_contrib"])+ar
Cmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="C"),"soil_contrib"])-ar

Pmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="P"),"soil_contrib"])+ar
Pmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="P"),"soil_contrib"])-ar

# Parameter ranges for min soil tolerance based on PFG types. 

HMINmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="H"),"soil_tol_min"])+ar
HMINmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="H"),"soil_tol_min"]) #it is already 0 should I leave like that?

CMINmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="C"),"soil_tol_min"])+ar
CMINmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="C"),"soil_tol_min"])-ar

PMINmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="P"),"soil_tol_min"])+ar
PMINmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="P"),"soil_tol_min"])-ar

# Parameter ranges for max soil tolerance based on PFG types. 
### DOUBLE CHECK? Landolt nutrient value range? ANSWER -> until 5 but min max until 6 
HMAXmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="H"),"soil_tol_max"])+ar
HMAXmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="H"),"soil_tol_max"])-ar

CMAXmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="C"),"soil_tol_max"])+ar
CMAXmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="C"),"soil_tol_max"])-ar

PMAXmax = max(mat.traits.pfg[which(mat.traits.pfg$type =="P"),"soil_tol_max"])+ar
PMAXmin = min(mat.traits.pfg[which(mat.traits.pfg$type =="P"),"soil_tol_max"])-ar

####### 1.d.ii Creating the dataset for soil parameters
######################################################################################################
soilparam = rbind(
  SRGermLow = c(0,4),#c(9.5,8.5), # 1PFG survival rate Germ Low
  SRImLow = c(3,7), #c(7.5,2.5), # 2PFG survival rate Im Low
  SRMLow = c(5,10),  #c(5.5,0), # 3PFG survival rate M Low
  SRGermHigh = c(0,4), # 4PFG survival rate Germ High
  SRImHigh = c(3,7), # 5PFG survival rate Im High
  SRMHigh = c(5,10), # 6PFG survival rate M High
  #Soil Contribution
  scH = c(Hmax,Hmin), # 7 herbs
  scC = c(Cmax,Cmin), # 8 shrubs
  scP = c(Pmax,Pmin), # 9 trees
  #min Soil Tolerance
  minstH= c(HMINmax,HMINmin), # 10 herbs
  minstC = c(CMINmax,CMINmin), # 11 shrubs
  minstP = c(PMINmax,PMINmin), # 12 trees
  #Max soil tolerance
  maxstH = c(HMAXmax,HMAXmin), # 13 herbs
  maxstC = c(CMAXmax,CMAXmin), # 14 shrubs
  maxstP = c(PMAXmax,PMAXmin)) # 15 trees
colnames(soilparam)<-c("plow","phigh")

####### 1.d.iii Constructing the soil parameter space
######################################################################################################
######## BEWARE: you will resample after the LHS so this part will come after 1.g
######## BEWARE DECISION: linear model for the medium conditions!

#### DO IT WHEN YOU UPDATE ANYHOW THE PFG TRAITS DATA
####### Just a small correction in traits table --> third PFG (P5) changed to C3
# class(mat.traits.pfg[,1])<-as.character(mat.traits.pfg[,1])
# mat.traits.pfg[,1]<-c("C1","C2","C3","H1","H2","H3","H4","H5","H6","H7","H8","P1","P2","P3","P4","P6")
# mat.traits.pfg[,1]<-as.factor(mat.traits.pfg[,1])
# save(mat.traits.pfg, file="mat.traits.pfg.RData")

####### 1.e. Bind all the parameters under a big matrix
######################################################################################################
ALLparams = rbind(paramglob,
                  seeding,
                  lightparam,
                  soilparam)

####### 1.f. LHS contraint function: for the parameters that need constraint
######################################################################################################
lhsconstraint = function(xx){ifelse(xx[c("minstH")]<= xx["scH"]&&
                                      xx[c("maxstH")]>= xx["scH"]&& 
                                      xx[c("minstC")]<= xx["scC"]&&
                                      xx[c("maxstC")]>= xx["scC"]&&
                                      xx[c("minstP")]<= xx["scP"]&&
                                      xx[c("maxstP")]>= xx["scP"]&&
                                      xx[c("seeding_timestep")]<= xx["seeding_duration"]&&
                                      xx[c("max_abund_low")]<= xx["max_abund_medium"]&&
                                      xx[c("max_abund_medium")]<= xx["max_abund_high"]&&
                                      xx[c("light_thres_medium")]<= xx["light_thres_low"],0,1)}

######## 1.g Latin Hypercube Sampling
######################################################################################################
set.seed(22121994) # You need to setseed everytime as lhs is also a random value generator. 
ALLparamspace = designLHD(,c(ALLparams[,1]),c(ALLparams[,2]),
                       control=list(size=3000, 
                       types=c(rep("integer",17),rep("numeric",9)),
                       inequalityConstraint=lhsconstraint))

par(mfrow=c(2,4))
for (i in 1:26){
  hist(ALLparamspace[,i],xlab="", main=paste(rownames(ALLparams)[i]))
}
colnames(ALLparamspace)<-rownames(ALLparams)

######## BACK! ####### 1.d.iii Constructing the soil parameter space
######################################################################################################
######## BEWARE: you will resample after the LHS so this part will come after 1.X
######## BEWARE DECISION: linear model for the medium conditions!
Hnum = 8
Cnum = 3
Pnum = 5
numsimul = 3000
set.seed(22121994)
solcontH = replicate(numsimul, sample(ALLparamspace[,c("scH")],Hnum))
solcontH = matrix(solcontH,nrow=numsimul,ncol=Hnum, byrow=T) 
set.seed(22121994)
solcontC = replicate(numsimul, sample(ALLparamspace[,"scC"],Cnum))
solcontC = matrix(solcontC,nrow=numsimul,ncol=Cnum, byrow=T) 
set.seed(22121994)
solcontP = replicate(numsimul, sample(ALLparamspace[,"scP"],Pnum))
solcontP = matrix(solcontP,nrow=numsimul,ncol=Pnum, byrow=T) 

paramsoilcont = cbind(solcontC, solcontH, solcontP)
#Sampling from LHS for min soil tolerance
set.seed(22121994)
soltolminH = replicate(numsimul, sample(ALLparamspace[,"minstH"],Hnum))
soltolminH = matrix(soltolminH,nrow=numsimul,ncol=Hnum, byrow=T) 
set.seed(22121994)
soltolminC = replicate(numsimul, sample(ALLparamspace[,"minstC"],Cnum))
soltolminC = matrix(soltolminC,nrow=numsimul,ncol=Cnum, byrow=T) 
set.seed(22121994)
soltolminP = replicate(numsimul, sample(ALLparamspace[,"minstP"],Pnum))
soltolminP = matrix(soltolminP,nrow=numsimul,ncol=Pnum, byrow=T) 

paramsoiltolmin = cbind(soltolminC,soltolminH, soltolminP)

#Sampling from LHS for max soil tolerance
set.seed(22121994)
soltolmaxH = replicate(numsimul, sample(ALLparamspace[,"maxstH"],Hnum))
soltolmaxH = matrix(soltolmaxH,nrow=numsimul,ncol=Hnum, byrow=T) 
set.seed(22121994)
soltolmaxC = replicate(numsimul, sample(ALLparamspace[,"maxstC"],Cnum))
soltolmaxC = matrix(soltolmaxC,nrow=numsimul,ncol=Cnum, byrow=T) 
set.seed(22121994)
soltolmaxP = replicate(numsimul, sample(ALLparamspace[,"maxstP"],Pnum))
soltolmaxP = matrix(soltolmaxP,nrow=numsimul,ncol=Pnum, byrow=T) 

paramsoiltolmax = cbind(soltolmaxC,soltolmaxH, soltolmaxP)

### Reorganizing the PFG trait table according to the sampling

PFGTraits = data.frame(mat.traits.pfg[order(mat.traits.pfg[,"type"]),])
rownames(mat.traits.pfg)<- c(1:16)

### Scaling medium condition PFG reduction rate with soil contrib
scalereduction = data.frame(reduction=seq(7,10,by=0.75),soilcontrib=c(1:5))
solreduct=lm(formula=reduction~soilcontrib,data=scalereduction)
#predict(solreduct, newdata=data.frame(soilcontrib=c(1.3)))


##### 2. Generate parameter files
######################################################################################################
###### 2.a. Create the skeleton
######################################################################################################
###### BEWARE: The trait table is "PFGTraits"
setwd("~/Desktop/FATEII/SensitivityAnalysis")
PRE_FATE.skeletonDirectory(name.simulation = "FATEGLOBAL")

###### 2.b. Generate the soil parameter files
######## 2.b.i A function to organize it
######################################################################################################
prepareFATEsoil=function(SA_NAME,PFGtraitTable,soilcontribution,soiltolmin,soiltolmax,paramlhs,numsimul){
  for (i in 1:numsimul){
    mat.PFG.soil = data.frame(PFG  = PFGtraitTable$PFG,
                              type = PFGtraitTable$type,
                              soil_contrib = c(soilcontribution[i,]),
                              soil_tol_min = c(soiltolmin[i,]),
                              soil_tol_max = c(soiltolmax[i,]))
    mat.PFG.tol = data.frame(PFG = rep(PFGtraitTable$PFG,each=9),
                             lifeStage = rep(c("Germinant","Immature","Mature"),each=3),
                             soilResources = rep(c("Low","Medium","High"),3),
                             soil_tol = rep(c(paramlhs[i,"SRGermLow"],
                                              100,
                                              paramlhs[i,"SRGermHigh"],
                                              paramlhs[i,"SRImLow"],
                                              100,
                                              paramlhs[i,"SRImHigh"],
                                              paramlhs[i,"SRMLow"],
                                              100,
                                              paramlhs[i,"SRMHigh"]),16))
    #Medium soil resources survival correction 
    for(j in 1:nrow(mat.PFG.tol)){
      if(mat.PFG.tol$soil_tol[j] == 100){
        mat.PFG.tol$soil_tol[j] <- round(predict(solreduct, 
                                                 newdata=data.frame(soilcontrib=c(mat.PFG.soil[which(mat.PFG.soil$PFG == mat.PFG.tol$PFG[j]),"soil_contrib"]))))
      }
    }
    
    PRE_FATE.params_PFGsoil(name.simulation = SA_NAME,
                            mat.PFG.soil=mat.PFG.soil,
                            mat.PFG.tol=mat.PFG.tol,opt.folder.name = paste("simul",i,sep="_"))
  }
}

prepareFATEsoil(SA_NAME ="FATEGLOBAL", 
                PFGTraits,
                paramsoilcont,
                paramsoiltolmin,
                paramsoiltolmax,
                ALLparamspace,
                3000
)

###### 2.c. Generate the light parameter files
##### BEWARE: Here we are using the modified function PREFATE_light_FORSA
######################################################################################################
strata.num=c()
for(i in 1:3000){
 strata.num=c(strata.num, PREFATE_light_FORSA(name.simulation="FATEGLOBAL", 
                      mat.PFG.succ = data.frame(PFG = PFGTraits$PFG,
                                                     type = PFGTraits$type,
                                                     height = PFGTraits$height,
                                                     maturity = PFGTraits$maturity,
                                                     longevity = PFGTraits$longevity,
                                                     light= as.numeric(PFGTraits$light)),
                      opt.folder.name = paste("simul",i,sep="_"),
                      simul.number = i, 
                      all_break.list = all_break,
                      numscenario = ALLparamspace[i,"shade_tolerance"],
                      scenariosST = scenarios))

  }

###### 2.d. Succession files
######################################################################################################

for(i in 1:3000){
  PREFATE_succ_FORSA(name.simulation="FATEGLOBAL", 
                     mat.PFG.succ = data.frame(PFG = PFGTraits$PFG,
                                                          type = PFGTraits$type,
                                                          height = PFGTraits$height,
                                                          maturity = PFGTraits$maturity,
                                                          longevity = PFGTraits$longevity),
                     opt.folder.name = paste("simul",i,sep="_"),
                     simul.number =i,
                     all_break.list = all_break)
}


###### 2.e. Save Years
######################################################################################################

PRE_FATE.params_saveYears(name.simulation = "FATEGLOBAL"
                          , years.maps = c(seq(20, 780, 20), seq(790, 1000, 10)))


###### 2.f. Changing years
######################################################################################################
zone.mask.pert.all = c("Bauges/MASK_grazing.tif", "Bauges/MASK_noPerturb.tif")
ras.names.dist = paste0("FATEGLOBAL", "/DATA/MASK/DIST_", basename(zone.mask.pert.all))
mat.dist.change = data.frame(year = rep(c(700, 701, 900, 901), each = 2)
                             , order = rep(1:2, 4)
                             , file.name = rep(c(ras.names.dist, rev(ras.names.dist)), 2))

PRE_FATE.params_changingYears(name.simulation = "FATEGLOBAL"
                              , type.changing = "DIST"
                              , mat.changing = mat.dist.change)


###### 2.g. Dispersal files
######################################################################################################
disper = matrix(c(c(1, 1, 2, 40, 100, 400, 500),
                  c(2, 5, 15, 150, 500, 1500, 5000),
                  c(79000,79000,79000,79000,79000,79000,79000))
                , 3, 7, byrow = TRUE)
colnames(disper) = 1:7
rownames(disper) = c("d50", "d99", "ldd")
(disper)

mat.disp = data.frame(PFG = PFGTraits$PFG
                      , MODE = 1
                      , d50 = disper[1, PFGTraits$dispersal]
                      , d99 = disper[2, PFGTraits$dispersal]
                      , ldd = disper[3, PFGTraits$dispersal])
for (i in 1:3000){
  PRE_FATE.params_PFGdispersal(name.simulation = "FATEGLOBAL",
                               mat.PFG.disp = mat.disp,
                               opt.folder.name = paste("simul",i,sep="_"))
}

###### 2.h. Disturbance Files
######################################################################################################
pfg_names = as.character(PFGTraits$PFG)
pfg_H = pfg_names[grep("^H|^G|^T", pfg_names)]
pfg_C = pfg_names[grep("^C", pfg_names)]
pfg_P = c("P1" ,"P2" ,"P3" ,"P4", "P6")

PFGTraits$palatability = as.numeric(as.character(PFGTraits$palatability))

mat.dist = data.frame()
mat.dist = rbind(mat.dist, data.frame(name = "mowing"
                                      , responseStage = c(rep(1:4, each = length(pfg_H))
                                                          , rep(1:4, each = length(pfg_C))
                                                          , rep(1:4, each = length(pfg_P)))
                                      , variable = c(rep(paste0("KilledIndiv_", pfg_H), 4)
                                                     , rep(paste0("KilledIndiv_", pfg_C), 4)
                                                     , rep(paste0("KilledIndiv_", pfg_P), 4))
                                      , value = c(rep(c(0, 0, 4, 10), each = length(pfg_H))
                                                  , rep(c(0, 10, 5, 10), each = length(pfg_C))
                                                  , rep(c(8, 10, 10, 10), each = length(pfg_P)))))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 1
                                      , variable = paste0("KilledIndiv_", PFGTraits$PFG[which(PFGTraits$palatability > 3)])
                                      , value = 1))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 1
                                      , variable = paste0("KilledIndiv_", pfg_P)
                                      , value = 10))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 2
                                      , variable = paste0("KilledIndiv_", pfg_P)
                                      , value = 0))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 2
                                      , variable = paste0("KilledIndiv_", PFGTraits$PFG[which(PFGTraits$palatability > 3)])
                                      , value = 1))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 3
                                      , variable = paste0("ResproutIndiv_", PFGTraits$PFG[which(PFGTraits$palatability %in% c(4,5))])
                                      , value = 1))
# mat.dist = rbind(mat.dist, data.frame(name = "graz1"
#                                       , responseStage = 3
#                                       , variable = paste0("ResproutIndiv_", mat.traits.pfg$PFG[which(mat.traits.pfg$palatability %in% c(6,7))])
#                                       , value = 5))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 3
                                      , variable = paste0("ResproutIndiv_", pfg_P)
                                      , value = 0))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 4
                                      , variable = paste0("ResproutIndiv_", pfg_P)
                                      , value = 0))
mat.dist = rbind(mat.dist, data.frame(name = "graz1"
                                      , responseStage = 4
                                      , variable = paste0("ResproutIndiv_", PFGTraits$PFG[which(PFGTraits$palatability > 3)])
                                      , value = 1))
mat.dist = tapply(X = mat.dist$value, INDEX = list(interaction(mat.dist$responseStage, mat.dist$name)
                                                   , mat.dist$variable), FUN = mean)
mat.dist[which(is.na(mat.dist))] = 0
mat.dist = as.data.frame(mat.dist)
mat.dist$name = sapply(rownames(mat.dist), function(x) strsplit(x, "[.]")[[1]][2])
mat.dist$responseStage = as.numeric(sapply(rownames(mat.dist), function(x) strsplit(x, "[.]")[[1]][1]))
if (sum(colnames(mat.dist) %in% paste0("ResproutIndiv_", pfg_names)) < length(pfg_names))
{
  for (pfg in pfg_names)
  {
    if(length(which(colnames(mat.dist) == paste0("ResproutIndiv_", pfg))) == 0)
    {
      eval(parse(text = paste0("mat.dist$ResproutIndiv_", pfg, " = 0")))
    }
  }
}


for (i in 1:3000){
  PREFATE_dist_FORSA(name.simulation = "FATEGLOBAL",
                                        mat.PFG.dist = mat.dist,
                                        mat.PFG.succ = paste0("FATEGLOBAL/DATA/PFGS/","simul_",i,"_","SUCC_COMPLETE_TABLE",".csv"),
                                        opt.folder.name = paste("simul",i,sep="_"))
  
}

###### 2.h. Global Parameter Files
######################################################################################################

###### simul.number = 1:3000 (Light & Soil)
### simul.number = 3001:6000 (NoLight & Soil)
###### simul.number = 6001:9000 (Light & NoSoil)
### simul.number = 9001:12000 (NoLight & NoSoil)

for (i in 1:3000){
RFate::PRE_FATE.params_globalParameters(name.simulation = "FATEGLOBAL"
                                 , opt.no_CPU = 7
                                 , required.no_PFG = 16 # Don't forget to change this
                                 , required.no_STRATA = strata.num[i] # Don't forget to change this
                                 , required.simul_duration = 1000 #only changed this one
                                 , required.seeding_duration = ALLparamspace[i,"seeding_duration"]
                                 , required.seeding_timestep = ALLparamspace[i,"seeding_timestep"]
                                 , required.seeding_input = ALLparamspace[i,"seeding_input"]
                                 , required.max_by_cohort = ALLparamspace[i,"cohort"]
                                 , required.max_abund_low = ALLparamspace[i,"max_abund_low"]
                                 , required.max_abund_medium = ALLparamspace[i,"max_abund_medium"]
                                 , required.max_abund_high = ALLparamspace[i,"max_abund_high"]
                                 , doDispersal = TRUE
                                 , doHabSuitability = TRUE
                                 , HABSUIT.ref_option = 1
                                 , doDisturbances = TRUE
                                 , DIST.no = 2
                                 , DIST.no_sub = 4
                                 , DIST.freq = c(1, 1)
                                 , doLight = F
                                 , LIGHT.thresh_medium = ALLparamspace[i,"light_thres_medium"]
                                 , LIGHT.thresh_low = ALLparamspace[i,"light_thres_low"]
                                 , doSoil = F)
}

###### 2.j. Simulation Parameteres Files
######################################################################################################

######################################################################################################
############# CREATING SIMULATION PARAMETER FILES IS NOT WORKING WITH THE CURRENT FUNCTION
############### because every simulation has its own Global Parameters 
############# DOING IT MANUALLY
######################################################################################################
### kill .createParams function afterwards
 
for (simul.number in 1:3000){
 params.list = list()
  names.params.list = list()
  
  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/GLOBAL_PARAMETERS/Global_parameters_V",simul.number+9000,".txt")))
  names.params.list = c(names.params.list,"--GLOBAL_PARAMS--")
  
  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/MASK/MASK_100m.tif")))
  names.params.list = c(names.params.list,"--MASK--")
  
  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/SAVE/SAVE_YEARS_maps.txt")))
  names.params.list = c(names.params.list,"--ARRAYS_SAVING_YEARS--")

  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/SCENARIO/DIST_changing_times.txt")))
  names.params.list = c(names.params.list,"--DIST_CHANGE_TIME--")

  params.list = c(params.list, list(paste0(name.simulation, "/RESULTS/SIMUL_V",simul.number+9000)))
  names.params.list = c(names.params.list, "--SAVE_DIR--")
  
  files.PFG.SUCC = list.files(paste0("FATEGLOBAL/DATA/PFGS/SUCC/","simul_",simul.number),full.names=T)
  params.list = c(params.list, list(files.PFG.SUCC))
  names.params.list = c(names.params.list, "--PFG_LIFE_HISTORY_PARAMS--")
  
  files.PFG.DISP = list.files(paste0("FATEGLOBAL/DATA/PFGS/DISP/","simul_",simul.number),full.names=T)
  params.list = c(params.list, list(files.PFG.DISP))
  names.params.list = c(names.params.list, "--PFG_DISPERSAL_PARAMS--")
  
  # files.PFG.LIGHT = list.files(paste0("FATEGLOBAL/DATA/PFGS/LIGHT/","simul_",simul.number),full.names=T)
  # params.list = c(params.list, list(files.PFG.LIGHT))
  # names.params.list = c(names.params.list, "--PFG_LIGHT_PARAMS--")

  # files.PFG.SOIL = list.files(paste0("FATEGLOBAL/DATA/PFGS/SOIL/","simul_",simul.number),full.names=T)
  # params.list = c(params.list, list(files.PFG.SOIL))
  # names.params.list = c(names.params.list, "--PFG_SOIL_PARAMS--")
  # 
  files.PFG.HAB = list.files(paste0("FATEGLOBAL/DATA/PFGS/HABSUIT/"),full.names=T)
  params.list = c(params.list, list(files.PFG.HAB))
  names.params.list = c(names.params.list, "--PFG_HAB_MASK--")
  
  files.PFG.DIST = list.files(paste0("FATEGLOBAL/DATA/PFGS/DIST/","simul_",simul.number),full.names=T)
  params.list = c(params.list, list(files.PFG.DIST))
  names.params.list = c(names.params.list, "--PFG_DISTURBANCES_PARAMS--")
  
  files.DIST.MASK = rep("FATEGLOBAL/DATA/MASK/DIST_MASK_noPerturb.tif",2)
  params.list = c(params.list, list(files.DIST.MASK))
  names.params.list = c(names.params.list, "--DIST_MASK--")
  
  files.PFG.SCENARIO = list.files(paste0("FATEGLOBAL/DATA/SCENARIO"),full.names=T)
  params.list = c(params.list, list(files.PFG.SCENARIO))
  names.params.list = c(names.params.list, "--DIST_CHANGE_MASK--")
  
  params = c(params.list, list(""))
  names(params) = c(names.params.list, "--END_OF_FILE--")
  
  .createParams(params.file = paste0(name.simulation
                                     , "/PARAM_SIMUL/Simul_parameters_V"
                                     , simul.number+9000
                                     , ".txt")
                , params.list = params
                , separator = "\n")
}
  
filesSA = list.files("/Users/apple/Desktop/FATEII/SensitivityAnalysis/FATEGLOBAL/PARAM_SIMUL")

filesSAV = data.frame(simul.num=parse_number(filesSA),
                       input.file = paste("FATESA/PARAM_SIMUL",c(filesSA),sep="/"),
                       output.file = paste("FATESA/Output",substring(filesSA,18),sep="_"))

#filesSAV2 = data.frame(input.file = c(filesSA[1001:2000]),
#output.file = paste("/FATESA/Output",substring(filesSA[1001:2000],18),sep="_"))

write.table(filesSAV2, "PARAMS_FATE_SA_V2.txt")
write.table(filesSAV, "PARAMS_FATEGLOBAL.txt", col.names=F,row.names=F,quote=F)

### Table of all Parameters for simulations
GSAsimul = data.frame(cbind(ALLparamspace[,c(1:17)],paramsoilcont,paramsoiltolmin,paramsoiltolmax))
colnames(GSAsimul)<- c(colnames(ALLparamspace)[1:17],
                      paste("soilcontrib",as.character(PFGTraits$PFG),sep=""),
                      paste("soiltolmin",as.character(PFGTraits$PFG),sep=""),
                      paste("soiltolmax",as.character(PFGTraits$PFG),sep=""))
GSAsimul$Simul_no = paste("simul",c(1:3000),sep="_")
save(GSAsimul,file="GSASimulParams.RData")













