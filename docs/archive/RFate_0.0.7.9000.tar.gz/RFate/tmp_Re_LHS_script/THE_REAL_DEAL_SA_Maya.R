library(SPOT)
######################################### FATEHD GLOBAL SENSITIVITY ANALYSIS ########################################
##### 1. Create the parameter space
######## 1.a. Global Model Thresholds
######################################################################################################
########### (The problem here is that some parameters need to be smaller than others so for it needs to be a lhs with constraint
########### which decreases the parameter space for other variables too)
############# DECISION: Checked and see that 50% is OK 

defaultglobparams = c(10000000,50000000,80000000,95000000,190000000,50000000)
names(defaultglobparams) = c("max_abund_low","max_abund_medium","max_abund_high","light_thres_medium","light_thres_low","cohort")
rangeglobparam = (defaultglobparams*50)/100
plow =defaultglobparams- rangeglobparam
phigh = defaultglobparams +rangeglobparam
paramglob = cbind(plow,phigh)

######## 1.b. Seeding parameters
######################################################################################################
######### (I will need a constraint between seeding duration and timestep)
seeding =rbind( seeding_duration=c(1,500), 
                seeding_timestep = c(1,100), 
                seeding_input = c(10,500)) 
colnames(seeding)<- c("plow","phigh")
######## 1.c. Light Related Parameters
######################################################################################################
######### DECISION: It does not really makes sense  to play with the PFGs'observed data, so we decided to play mainly with related parameters
######### DECISION: Different scenarios for attributing shade tolerance 
###################(Scenarios for shade tolerance which will define the variation
###################### because we already vary the the thresholds in global parameters.)
######### ATTENTION: These need to be done at the stage of preparing the light parameter files.
######### 1.c.i Creating the dataset for light parameters
lightparam = rbind(strata_limits = c(3,7),
                   shade_tolerance = c(1,27)) #scenario number
colnames(lightparam)<- c("plow","phigh")
######## 1.c.ii Creating the scenarios table for shade tolerance
######################################################################################################
# Germinants:    1a) tolerant to Low light
#                1b) tolerant to Medium Light
#                1c) tolerant to Medium and Low Light
# Mature Shrubs: 2a) tolerant to Low light
#                2b) tolerant to Medium Light
#                2c) tolerant to Medium and Low Light
# Mature Trees : 3a) tolerant to Low light
#                3b) tolerant to Medium Light
#                3c) tolerant to Medium and Low Light
scenarios = expand.grid(G = c("1a","1b","1c"), Cm = c("2a","2b","2c"),Pm=c("3a","3b","3c"))

######## 1.c.iii Strata limits
######################################################################################################
######### sort(all_break[i]) should be the strata.limits defined in the PRE_FATE.params_PFGlight function
########## for the corresponding simulation. 

#break_param = as.numeric(c(0,4,5,7,8,9,10,20,30,40,50,60,70)^2)
break_param = c(0,25,31,80,300,900,3600)
all_break =list()
# all_break_hist=c()
for (i in 1:length(ALLparamspace[,"strata_limits"])){
  num = ALLparamspace[i,"strata_limits"]
  all_break[[i]] <- sample(break_param,num)
  # all_break_hist<- c(all_break_hist, c(sample(break_param,num)))
}
# cutcut = cut(all_break_hist,breaks=break_param)
# barplot(table(cutcut))
# 
######## 1.c.iv CHANGING THE PRE_FATE.params_PFGlight ---> PREFATE_light_FORSA function 
######################################################################################################
########## to be able to create new height breaks.
########## AND implement the different scenarios. 
########## BEWARE: new arguments are put for the function
# numlimStrata = as the ALLparamspace[,"strata_limits"]
# all_break.list = as the break sequences that you created from the lhs strata_limits
# numscenario = the scenario number from LHS shade_tolerance
# scenariosST = scenario data frame that I created here

####### 1.e. Bind all the parameters under a big matrix
######################################################################################################
ALLparams = rbind(paramglob,
                  seeding,
                  lightparam,
                  soilparam)

####### 1.f. LHS contraint function: for the parameters that need constraint
######################################################################################################
lhsconstraint = function(xx){ifelse(xx[c("minstH")]<= xx["scH"]&&
                                      xx[c("maxstH")]>= xx["scH"]&& 
                                      xx[c("minstC")]<= xx["scC"]&&
                                      xx[c("maxstC")]>= xx["scC"]&&
                                      xx[c("minstP")]<= xx["scP"]&&
                                      xx[c("maxstP")]>= xx["scP"]&&
                                      xx[c("seeding_timestep")]<= xx["seeding_duration"]&&
                                      xx[c("max_abund_low")]<= xx["max_abund_medium"]&&
                                      xx[c("max_abund_medium")]<= xx["max_abund_high"]&&
                                      xx[c("light_thres_medium")]<= xx["light_thres_low"],0,1)}

######## 1.g Latin Hypercube Sampling
######################################################################################################
set.seed(22121994) # You need to setseed everytime as lhs is also a random value generator. 
ALLparamspace = designLHD(c(ALLparams[,1]),c(ALLparams[,2]),
                       control=list(size=3000, 
                       types=c(rep("integer",17),rep("numeric",9)),
                       inequalityConstraint=lhsconstraint))

par(mfrow=c(2,4))
for (i in 1:26){
  hist(ALLparamspace[,i],xlab="", main=paste(rownames(ALLparams)[i]))
}
colnames(ALLparamspace)<-rownames(ALLparams)


##### 2. Generate parameter files
######################################################################################################
###### 2.a. Create the skeleton
######################################################################################################
###### BEWARE: The trait table is "PFGTraits"
setwd("~/Desktop/FATEII/SensitivityAnalysis")
PRE_FATE.skeletonDirectory(name.simulation = "FATEGLOBAL")


###### 2.c. Generate the light parameter files
##### BEWARE: Here we are using the modified function PREFATE_light_FORSA
######################################################################################################
strata.num=c()
for(i in 1:3000){
 strata.num=c(strata.num, PREFATE_light_FORSA(name.simulation="FATEGLOBAL", 
                      mat.PFG.succ = data.frame(PFG = PFGTraits$PFG,
                                                     type = PFGTraits$type,
                                                     height = PFGTraits$height,
                                                     maturity = PFGTraits$maturity,
                                                     longevity = PFGTraits$longevity,
                                                     light= as.numeric(PFGTraits$light)),
                      opt.folder.name = paste("simul",i,sep="_"),
                      simul.number = i, 
                      all_break.list = all_break,
                      numscenario = ALLparamspace[i,"shade_tolerance"],
                      scenariosST = scenarios))

  }

###### 2.d. Succession files
######################################################################################################

for(i in 1:3000){
  PREFATE_succ_FORSA(name.simulation="FATEGLOBAL", 
                     mat.PFG.succ = data.frame(PFG = PFGTraits$PFG,
                                                          type = PFGTraits$type,
                                                          height = PFGTraits$height,
                                                          maturity = PFGTraits$maturity,
                                                          longevity = PFGTraits$longevity),
                     opt.folder.name = paste("simul",i,sep="_"),
                     simul.number =i,
                     all_break.list = all_break)
}


###### 2.h. Disturbance Files
######################################################################################################


for (i in 1:3000){
  PREFATE_dist_FORSA(name.simulation = "FATEGLOBAL",
                                        mat.PFG.dist = mat.dist,
                                        mat.PFG.succ = paste0("FATEGLOBAL/DATA/PFGS/","simul_",i,"_","SUCC_COMPLETE_TABLE",".csv"),
                                        opt.folder.name = paste("simul",i,sep="_"))
  
}

###### 2.h. Global Parameter Files
######################################################################################################

###### simul.number = 1:3000 (Light & Soil)
### simul.number = 3001:6000 (NoLight & Soil)
###### simul.number = 6001:9000 (Light & NoSoil)
### simul.number = 9001:12000 (NoLight & NoSoil)

for (i in 1:3000){
RFate::PRE_FATE.params_globalParameters(name.simulation = "FATEGLOBAL"
                                 , opt.no_CPU = 7
                                 , required.no_PFG = 16 # Don't forget to change this
                                 , required.no_STRATA = strata.num[i] # Don't forget to change this
                                 , required.simul_duration = 1000 #only changed this one
                                 , required.seeding_duration = ALLparamspace[i,"seeding_duration"]
                                 , required.seeding_timestep = ALLparamspace[i,"seeding_timestep"]
                                 , required.seeding_input = ALLparamspace[i,"seeding_input"]
                                 , required.max_by_cohort = ALLparamspace[i,"cohort"]
                                 , required.max_abund_low = ALLparamspace[i,"max_abund_low"]
                                 , required.max_abund_medium = ALLparamspace[i,"max_abund_medium"]
                                 , required.max_abund_high = ALLparamspace[i,"max_abund_high"]
                                 , doDispersal = TRUE
                                 , doHabSuitability = TRUE
                                 , HABSUIT.ref_option = 1
                                 , doDisturbances = TRUE
                                 , DIST.no = 2
                                 , DIST.no_sub = 4
                                 , DIST.freq = c(1, 1)
                                 , doLight = F
                                 , LIGHT.thresh_medium = ALLparamspace[i,"light_thres_medium"]
                                 , LIGHT.thresh_low = ALLparamspace[i,"light_thres_low"]
                                 , doSoil = F)
}

###### 2.j. Simulation Parameteres Files
######################################################################################################

######################################################################################################
############# CREATING SIMULATION PARAMETER FILES IS NOT WORKING WITH THE CURRENT FUNCTION
############### because every simulation has its own Global Parameters 
############# DOING IT MANUALLY
######################################################################################################
### kill .createParams function afterwards
 
for (simul.number in 1:3000){
 params.list = list()
  names.params.list = list()
  
  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/GLOBAL_PARAMETERS/Global_parameters_V",simul.number+9000,".txt")))
  names.params.list = c(names.params.list,"--GLOBAL_PARAMS--")
  
  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/MASK/MASK_100m.tif")))
  names.params.list = c(names.params.list,"--MASK--")
  
  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/SAVE/SAVE_YEARS_maps.txt")))
  names.params.list = c(names.params.list,"--ARRAYS_SAVING_YEARS--")

  params.list = c(params.list,list(paste0("FATEGLOBAL/DATA/SCENARIO/DIST_changing_times.txt")))
  names.params.list = c(names.params.list,"--DIST_CHANGE_TIME--")

  params.list = c(params.list, list(paste0(name.simulation, "/RESULTS/SIMUL_V",simul.number+9000)))
  names.params.list = c(names.params.list, "--SAVE_DIR--")
  
  files.PFG.SUCC = list.files(paste0("FATEGLOBAL/DATA/PFGS/SUCC/","simul_",simul.number),full.names=T)
  params.list = c(params.list, list(files.PFG.SUCC))
  names.params.list = c(names.params.list, "--PFG_LIFE_HISTORY_PARAMS--")
  
  files.PFG.DISP = list.files(paste0("FATEGLOBAL/DATA/PFGS/DISP/","simul_",simul.number),full.names=T)
  params.list = c(params.list, list(files.PFG.DISP))
  names.params.list = c(names.params.list, "--PFG_DISPERSAL_PARAMS--")
  
  # files.PFG.LIGHT = list.files(paste0("FATEGLOBAL/DATA/PFGS/LIGHT/","simul_",simul.number),full.names=T)
  # params.list = c(params.list, list(files.PFG.LIGHT))
  # names.params.list = c(names.params.list, "--PFG_LIGHT_PARAMS--")

  # files.PFG.SOIL = list.files(paste0("FATEGLOBAL/DATA/PFGS/SOIL/","simul_",simul.number),full.names=T)
  # params.list = c(params.list, list(files.PFG.SOIL))
  # names.params.list = c(names.params.list, "--PFG_SOIL_PARAMS--")
  # 
  files.PFG.HAB = list.files(paste0("FATEGLOBAL/DATA/PFGS/HABSUIT/"),full.names=T)
  params.list = c(params.list, list(files.PFG.HAB))
  names.params.list = c(names.params.list, "--PFG_HAB_MASK--")
  
  files.PFG.DIST = list.files(paste0("FATEGLOBAL/DATA/PFGS/DIST/","simul_",simul.number),full.names=T)
  params.list = c(params.list, list(files.PFG.DIST))
  names.params.list = c(names.params.list, "--PFG_DISTURBANCES_PARAMS--")
  
  files.DIST.MASK = rep("FATEGLOBAL/DATA/MASK/DIST_MASK_noPerturb.tif",2)
  params.list = c(params.list, list(files.DIST.MASK))
  names.params.list = c(names.params.list, "--DIST_MASK--")
  
  files.PFG.SCENARIO = list.files(paste0("FATEGLOBAL/DATA/SCENARIO"),full.names=T)
  params.list = c(params.list, list(files.PFG.SCENARIO))
  names.params.list = c(names.params.list, "--DIST_CHANGE_MASK--")
  
  params = c(params.list, list(""))
  names(params) = c(names.params.list, "--END_OF_FILE--")
  
  .createParams(params.file = paste0(name.simulation
                                     , "/PARAM_SIMUL/Simul_parameters_V"
                                     , simul.number+9000
                                     , ".txt")
                , params.list = params
                , separator = "\n")
}
  
filesSA = list.files("/Users/apple/Desktop/FATEII/SensitivityAnalysis/FATEGLOBAL/PARAM_SIMUL")

filesSAV = data.frame(simul.num=parse_number(filesSA),
                       input.file = paste("FATESA/PARAM_SIMUL",c(filesSA),sep="/"),
                       output.file = paste("FATESA/Output",substring(filesSA,18),sep="_"))

#filesSAV2 = data.frame(input.file = c(filesSA[1001:2000]),
#output.file = paste("/FATESA/Output",substring(filesSA[1001:2000],18),sep="_"))

write.table(filesSAV2, "PARAMS_FATE_SA_V2.txt")
write.table(filesSAV, "PARAMS_FATEGLOBAL.txt", col.names=F,row.names=F,quote=F)

### Table of all Parameters for simulations
GSAsimul = data.frame(cbind(ALLparamspace[,c(1:17)],paramsoilcont,paramsoiltolmin,paramsoiltolmax))
colnames(GSAsimul)<- c(colnames(ALLparamspace)[1:17],
                      paste("soilcontrib",as.character(PFGTraits$PFG),sep=""),
                      paste("soiltolmin",as.character(PFGTraits$PFG),sep=""),
                      paste("soiltolmax",as.character(PFGTraits$PFG),sep=""))
GSAsimul$Simul_no = paste("simul",c(1:3000),sep="_")
save(GSAsimul,file="GSASimulParams.RData")













