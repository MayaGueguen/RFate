
tabPanel(title = HTML("<span class='tabPanel_title'>Scenario files</span>")
         , value = "panel.scenario"
         , sidebarLayout(
           sidebarPanel = NULL,
           mainPanel = mainPanel(
             width = 12,
             fluidRow(
               column(6
                      , br()
                      , wellPanel(
                        HTML("<strong>Save maps ?</strong>")
                        , br()
                        , br()
                        , textInput(inputId = "save.maps.folder"
                                    , label = param.style("opt.folder.name")
                                    , value = NULL
                                    , width = "100%")
                        , br()
                        , br()
                        , numericInput(inputId = "save.maps.year1"
                                       , label = param.style("years.maps.start")
                                       , value = 0
                                       , min = 0
                                       , width = "100%")
                        , numericInput(inputId = "save.maps.year2"
                                       , label = param.style("years.maps.end")
                                       , value = 0
                                       , min = 0
                                       , width = "100%")
                        , numericInput(inputId = "save.maps.no"
                                       , label = param.style("years.maps.number")
                                       , value = 0
                                       , min = 0
                                       , max = 100
                                       , step = 10
                                       , width = "100%")
                        , br()
                        , br()
                        , actionButton(inputId = "create.save.maps"
                                       , label = "Create SAVE maps files"
                                       , icon = icon("file")
                                       , width = "100%"
                                       , style = HTML(button.style)
                        )
                      ) %>% helper(type = "inline"
                                   , title = "Create SAVE maps files"
                                   , size = "l"
                                   , content = help.HTML("https://mayagueguen.github.io/RFate/reference/PRE_FATE.params_saveYears.html")
                      )
               )
               , column(6
                        , br()
                        , wellPanel(
                          HTML("<strong>Save simulation ?</strong>")
                          , br()
                          , br()
                          , textInput(inputId = "save.objects.folder"
                                      , label = param.style("opt.folder.name")
                                      , value = NULL
                                      , width = "100%")
                          , br()
                          , br()
                          , numericInput(inputId = "save.objects.year1"
                                         , label = param.style("years.objects")
                                         , value = 0
                                         , min = 0
                                         , width = "100%")
                          , numericInput(inputId = "save.objects.year2"
                                         , label = NULL
                                         , value = 0
                                         , min = 0
                                         , width = "100%")
                          , numericInput(inputId = "save.objects.year3"
                                         , label = NULL
                                         , value = 0
                                         , min = 0
                                         , width = "100%")
                          , br()
                          , br()
                          , actionButton(inputId = "create.save.objects"
                                         , label = "Create SAVE objects files"
                                         , icon = icon("file")
                                         , width = "100%"
                                         , style = HTML(button.style)
                          )
                        ) %>% helper(type = "inline"
                                     , title = "Create SAVE objects files"
                                     , size = "l"
                                     , content = help.HTML("https://mayagueguen.github.io/RFate/reference/PRE_FATE.params_saveYears.html")
                        )
               )
               )
             , fluidRow(
               br()
               , br()
               , br()
               , br()
               , column(12
                        , wellPanel(style = HTML(paste0("border-width:0px; background-color:", help.color, "; margin-left:15px; margin-top:18px; overflow-y:scroll; max-height:250px;"))
                                    , uiOutput(outputId = "UI.files.save")))
               , column(12
                        , wellPanel(style = HTML(paste0("border-width:0px; background-color:", help.color, "; margin-left:15px; margin-top:18px; overflow-x:scroll;"))
                                    , dataTableOutput(outputId = "created_table.save"))
               )
             )
         ) ## END mainPanel
         ) ## END sidebarLayout
         ) ## END tabPanel (Scenario files)
