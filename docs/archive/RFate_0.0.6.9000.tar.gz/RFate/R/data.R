### HEADER #####################################################################
##' @title Mont Blanc dataset
##' 
##' @name MontBlanc
##'
##' @author Maya Guéguen
##' 
##' @description MontBlanc dataset
##' 
##' @format A \code{list} object with 3 elements :
##' 
##' \itemize{
##'   \item 
##'   \item 
##'   \item 
##' }
##' 
## END OF HEADER ###############################################################
"MontBlanc"