### HEADER #####################################################################
##' @title Find cutoff to transform abundance values into binary values
##' 
##' @name .getCutoff
##'
##' @description This functions finds the best cutoff to transform abundance 
##' values into binary values while optimising sensitivity and specificity 
##' values based on observations
##' 
##' @param Obs a \code{vector} containing binary observed values (0/1)
##' @param Fit a \code{vector} containing abundance values
##' 
##' @examples
##' 
##' @export
##'
## END OF HEADER ###############################################################

.getCutoff <- function(Obs, Fit)
{
  if (.testParam_notNum(Obs))
  {
    .stopMessage_content("Obs", c("0", "1"))
  }
  if (.testParam_notNum(Fit))
  {
    .stopMessage_content("Fit", c("0", "1"))
  }
  
  SumObs = sum(Obs)
  LengObs = length(Obs)
  tt = c(100)
  
  Quant = quantile(Fit)
  if (sum(Quant) > 0 && sum(Quant) < 5)
  {
    i = Quant[2]
    a = 2
    while (i <= Quant[5])
    {
      se = sum((Fit >= i)[Obs == 1]) / SumObs
      sp = sum((Fit < i)[Obs == 0]) / (LengObs - SumObs)
      tt[a] = abs(se - sp)
      if (tt[a] > tt[a - 1])
        break
      i = i + ((Quant[5] - Quant[2]) / 1000)
      a = a + 1
    }
    
    b = (i - ((Quant[5] - Quant[2]) / 1000))
    Cut = as.numeric(b)
    
    Sensitivity = 100 * sum((Fit >= b)[Obs == 1]) / SumObs
    Specificity = 100 * sum((Fit < b)[Obs == 0]) / (LengObs - SumObs)
    
    return(list(Cut = Cut
                , Sensitivity = Sensitivity
                , Specificity = Specificity
    ))
  } else
  {
    return(NA)
  }
}