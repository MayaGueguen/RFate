library(RFate)
context("PRE_FATE.params_multipleSet() function")

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with missing data", {
  expect_error(PRE_FATE.params_multipleSet()
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
  expect_error(PRE_FATE.params_multipleSet(NA)
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
  expect_error(PRE_FATE.params_multipleSet(NULL)
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
})


## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : name.simulation.1", {
  expect_error(PRE_FATE.params_multipleSet(1)
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
  expect_error(PRE_FATE.params_multipleSet("a")
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
  expect_error(PRE_FATE.params_multipleSet(factor(1))
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
  expect_error(PRE_FATE.params_multipleSet(matrix(seq(2), ncol=2))
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
  
  if (dir.exists("FATE_simulation")) unlink("FATE_simulation", recursive = TRUE)
  dir.create("FATE_simulation")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation")
               , "`name.simulation.1` does not exist or does not contain a PARAM_SIMUL/ folder")
  dir.create("FATE_simulation/PARAM_SIMUL")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation")
               , "`name.simulation.1` does not exist or does not contain a DATA/GLOBAL_PARAMETERS/ folder")
  dir.create("FATE_simulation/DATA")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation")
               , "`name.simulation.1` does not exist or does not contain a DATA/GLOBAL_PARAMETERS/ folder")
  dir.create("FATE_simulation/DATA/GLOBAL_PARAMETERS")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation")
               , "Missing data!\n The folder FATE_simulation/PARAM_SIMUL/ does not contain adequate files")
  file.create("FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation")
               , "Missing data!\n The folder FATE_simulation/PARAM_SIMUL/ contain one or more files")
})

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : file.simulParam.1", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = NA)
               , "Missing data!\n The folder FATE_simulation/PARAM_SIMUL/ contain one or more files")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = 1)
               , "Missing data!\n The folder FATE_simulation/PARAM_SIMUL/ contain one or more files")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = factor("a"))
               , "Missing data!\n The folder FATE_simulation/PARAM_SIMUL/ contain one or more files")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "a")
               , "Wrong name file given!\n `FATE_simulation/PARAM_SIMUL/a` does not exist")
  
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt")
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
})


## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : file.simulParam.2", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = NA)
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = 1)
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = factor("a"))
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "a")
               , "Wrong name file given!\n `FATE_simulation/PARAM_SIMUL/a` does not exist")
  
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt")
               , "You must select different simulation parameter files !")
  file.create("FATE_simulation/PARAM_SIMUL/toto2.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto2.txt")
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
})

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : name.simulation.2", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , name.simulation.2 = "a")
               , "Missing data!\n The folder FATE_simulation/PARAM_SIMUL/ contain one or more files.")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , name.simulation.2 = "a")
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = "a")
               , "`name.simulation.2` does not exist or does not contain a PARAM_SIMUL/ folder")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = factor(1))
               , "You must select different simulation parameter files !")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = matrix(seq(2), ncol=2))
               , "You must select different simulation parameter files !")
  
  
  if (dir.exists("FATE_simulation2")) unlink("FATE_simulation2", recursive = TRUE)
  dir.create("FATE_simulation2")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = "FATE_simulation2")
               , "`name.simulation.2` does not exist or does not contain a PARAM_SIMUL/ folder")
  dir.create("FATE_simulation2/PARAM_SIMUL")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = "FATE_simulation2")
               , "`name.simulation.2` does not exist or does not contain a DATA/GLOBAL_PARAMETERS/ folder")
  dir.create("FATE_simulation2/DATA")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = "FATE_simulation2")
               , "`name.simulation.2` does not exist or does not contain a DATA/GLOBAL_PARAMETERS/ folder")
  dir.create("FATE_simulation2/DATA/GLOBAL_PARAMETERS")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = "FATE_simulation2")
               , "Wrong name file given!\n `FATE_simulation2/PARAM_SIMUL/toto.txt` does not exist")
  
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = "FATE_simulation")
               , "You must select different simulation parameter files !")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto2.txt"
                                           , name.simulation.2 = "FATE_simulation")
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  file.create("FATE_simulation2/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , file.simulParam.2 = "toto.txt"
                                           , name.simulation.2 = "FATE_simulation2")
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
})


## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : no_simulations", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = NA)
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = NULL)
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = factor(1))
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = "")
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = factor("a"))
               , "Wrong type of data!\n `no_simulations` must be an integer > 0")
  
  # expect_warning(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
  #                                            , file.simulParam.1 = "toto.txt"
  #                                            , no_simulations = 3.2
  #                                            , opt.percent_max = -1)
  #                , "`no_simulations` is a double. It will be converted (rounded) to an integer")
})

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : opt.percent_max", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_max = NA)
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_max = NULL)
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_max = factor(1))
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_max = -2)
               , "Wrong data given!\n `opt.percent_max` must be between 0 and 1")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_max = 1.01)
               , "Wrong data given!\n `opt.percent_max` must be between 0 and 1")
})

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : opt.percent_seeding", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_seeding = NA)
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_seeding = NULL)
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_seeding = factor(1))
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_seeding = -2)
               , "Wrong data given!\n `opt.percent_seeding` must be between 0 and 1")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_seeding = 1.01)
               , "Wrong data given!\n `opt.percent_seeding` must be between 0 and 1")
})

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : opt.percent_light", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_light = NA)
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_light = NULL)
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_light = factor(1))
               , "Wrong data given!\n `opt.percent_max`, `opt.percent_seeding` and `opt.percent_light` must contain numeric values")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_light = -2)
               , "Wrong data given!\n `opt.percent_light` must be between 0 and 1")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , opt.percent_light = 1.01)
               , "Wrong data given!\n `opt.percent_light` must be between 0 and 1")
})

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : do...", {
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.max_by_cohort = FALSE
                                           , do.max_abund_low = FALSE
                                           , do.max_abund_medium = FALSE
                                           , do.max_abund_high = FALSE
                                           , do.seeding_duration = FALSE
                                           , do.seeding_timestep = FALSE
                                           , do.seeding_input = FALSE
                                           , do.nb_stratum = FALSE
                                           , do.LIGHT.thresh_medium = FALSE
                                           , do.LIGHT.thresh_low = FALSE
                                           , do.DISPERSAL.mode = FALSE
                                           , do.HABSUIT.ref_option = FALSE)
               , "You must select some parameters to vary !")
})

## INPUTS
test_that("PRE_FATE.params_multipleSet gives error with wrong data : within file.simulParam.1", {
  if (dir.exists("FATE_simulation_MULTIPLE_SET")) unlink("FATE_simulation_MULTIPLE_SET", recursive = TRUE)
  
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "The file FATE_simulation/PARAM_SIMUL/toto.txt is empty. Please check.")
  cat("Yo\n", file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "The file FATE_simulation/PARAM_SIMUL/toto.txt does not contain any parameter values with the --PARAM-- flag. Please check.")
  cat("--Yo--\n", file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "The file FATE_simulation/PARAM_SIMUL/toto.txt does not contain the --END_OF_FILE-- flag. Please check.")
  cat("--Yo--\n--END_OF_FILE--\n", file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "Wrong type of data!\n `flag` (GLOBAL_PARAMS) is not found within `params.lines` (FATE_simulation/PARAM_SIMUL/toto.txt)"
               , fixed = TRUE)
  cat("--GLOBAL_PARAMS--\n--END_OF_FILE--\n", file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "Wrong type of data!\n `flag` (GLOBAL_PARAMS) does not contain any value"
               , fixed = TRUE)
  cat("--GLOBAL_PARAMS--\nFATE_simulation/glob.txt\n--END_OF_FILE--\n", file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "Wrong name file given!\n `./FATE_simulation/glob.txt` does not exist"
               , fixed = TRUE)
  file.create("FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "The file ./FATE_simulation/glob.txt is empty. Please check.")
  cat("Yo", file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "The global parameter file indicated in FATE_simulation/PARAM_SIMUL/toto.txt does not contain any of the required parameter values (MAX_BY_COHORT, MAX_ABUND_LOW, MAX_ABUND_MEDIUM, MAX_ABUND_HIGH, SEEDING_DURATION, SEEDING_TIMESTEP, SEEDING_INPUT, LIGHT_THRESH_MEDIUM, LIGHT_THRESH_LOW, HABSUIT_OPTION, DISPERSAL_MODE, NB_STRATUM). Please check."
               , fixed = TRUE)
  cat("MAX_BY_COHORT", file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10)
               , "Wrong type of data!\n `flag.split` ( ) is not found within `params.lines` (./FATE_simulation/glob.txt)"
               , fixed = TRUE)
  cat("MAX_BY_COHORT 10000", file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE)
               , "The flag --PFG_LIFE_HISTORY_PARAMS-- in the file FATE_simulation/PARAM_SIMUL/toto.txt does not contain any value. Please check.")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag.split` ( ) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat("MAX_BY_COHORT 10000\nTRUC 3", file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (DO_DISPERSAL) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat("MAX_BY_COHORT 10000\nTRUC 3\nDO_DISPERSAL 0"
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (DO_HAB_SUITABILITY) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat("MAX_BY_COHORT 10000\nTRUC 3\nDO_DISPERSAL 0\nDO_HAB_SUITABILITY 0"
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (DO_LIGHT_COMPETITION) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat("MAX_BY_COHORT 10000\nTRUC 3\nDO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0"
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (DO_SOIL_COMPETITION) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat("MAX_BY_COHORT 10000\nTRUC 3\nDO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0"
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (DO_DISTURBANCES) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nTRUC 3\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (NB_FG) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (NB_STRATUM) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (SIMULATION_DURATION) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\nSIMULATION_DURATION 50\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (SEEDING_DURATION) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\nSIMULATION_DURATION 50\n"
             , "SEEDING_DURATION 10\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (SEEDING_TIMESTEP) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\nSIMULATION_DURATION 50\n"
             , "SEEDING_DURATION 10\nSEEDING_TIMESTEP 2\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (SEEDING_INPUT) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\nSIMULATION_DURATION 50\n"
             , "SEEDING_DURATION 10\nSEEDING_TIMESTEP 2\nSEEDING_INPUT 100\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (MAX_ABUND_LOW) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\nSIMULATION_DURATION 50\n"
             , "SEEDING_DURATION 10\nSEEDING_TIMESTEP 2\nSEEDING_INPUT 100\n"
             , "MAX_ABUND_LOW 500000\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (MAX_ABUND_MEDIUM) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\nSIMULATION_DURATION 50\n"
             , "SEEDING_DURATION 10\nSEEDING_TIMESTEP 2\nSEEDING_INPUT 100\n"
             , "MAX_ABUND_LOW 500000\nMAX_ABUND_MEDIUM 600000\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `flag` (MAX_ABUND_HIGH) is not found within `params.lines` (FATE_simulation_MULTIPLE_SET/tmp_global_param.txt)"
               , fixed = TRUE)
  cat(paste0("MAX_BY_COHORT 10000\nNB_FG 3\nNB_STRATUM 4\nSIMULATION_DURATION 50\n"
             , "SEEDING_DURATION 10\nSEEDING_TIMESTEP 2\nSEEDING_INPUT 100\n"
             , "MAX_ABUND_LOW 500000\nMAX_ABUND_MEDIUM 600000\nMAX_ABUND_HIGH 700000\n"
             , "DO_DISPERSAL 0\nDO_HAB_SUITABILITY 0\nDO_LIGHT_COMPETITION 0\nDO_SOIL_COMPETITION 0\nDO_DISTURBANCES 0")
      , file = "FATE_simulation/glob.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "The flag --MASK-- in the file FATE_simulation/PARAM_SIMUL/toto.txt does not contain any value. Please check."
               , fixed = TRUE)
  cat("--GLOBAL_PARAMS--\nFATE_simulation/glob.txt\n--MASK--\n--END_OF_FILE--\n"
      , file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong type of data!\n `name.mask` must contain a character value of length > 0"
               , fixed = TRUE)
  cat("--GLOBAL_PARAMS--\nFATE_simulation/glob.txt\n--MASK--\nmask.txt\n--END_OF_FILE--\n"
      , file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong name file given!\n `FATE_simulation_MULTIPLE_SET/DATA/MASK/mask.txt` does not exist")
  dir.create("FATE_simulation/DATA/MASK")
  file.create("FATE_simulation/DATA/MASK/mask.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "Wrong name file given!\n `FATE_simulation_MULTIPLE_SET/DATA/MASK/mask.txt` does not exist")
  cat("--GLOBAL_PARAMS--\nFATE_simulation/glob.txt\n--MASK--\nFATE_simulation/DATA/MASK/mask.txt\n--END_OF_FILE--\n"
      , file = "FATE_simulation/PARAM_SIMUL/toto.txt")
  expect_error(PRE_FATE.params_multipleSet(name.simulation.1 = "FATE_simulation"
                                           , file.simulParam.1 = "toto.txt"
                                           , no_simulations = 10
                                           , do.DISPERSAL.mode = FALSE
                                           , do.nb_stratum = FALSE)
               , "There is not the same number of files (`.txt` file starting with `SUCC`) into the DATA/PFGS/SUCC/ folder as the number of PFG indicated into the file FATE_simulation_MULTIPLE_SET/DATA/GLOBAL_PARAMETERS/Global_parameters_V1.txt"
               , fixed = TRUE)
  dir.create("FATE_simulation/DATA/PFGS")
  dir.create("FATE_simulation/DATA/PFGS/SUCC")
  file.create("FATE_simulation/DATA/PFGS/SUCC/SUCC_1.txt")
  file.create("FATE_simulation/DATA/PFGS/SUCC/SUCC_2.txt")
  file.create("FATE_simulation/DATA/PFGS/SUCC/SUCC_3.txt")
  cat(paste0("--GLOBAL_PARAMS--\nFATE_simulation/glob.txt\n"
             , "--MASK--\nFATE_simulation/DATA/MASK/mask.txt\n"
             , "--PFG_LIFE_HISTORY_PARAMS--\nFATE_simulation/DATA/PFGS/SUCC/SUCC_1.txt\n"
             , "FATE_simulation/DATA/PFGS/SUCC/SUCC_2.txt\nFATE_simulation/DATA/PFGS/SUCC/SUCC_3.txt\n"
             , "--END_OF_FILE--\n")
      , file = "FATE_simulation/PARAM_SIMUL/toto.txt")
})

