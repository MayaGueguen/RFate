library(RFate)
context("PRE_FATE.selectDominant() function")

## INPUT
test_that("PRE_FATE.selectDominant gives error with wrong type of data", {
  expect_error(PRE_FATE.selectDominant(), "No data given!")
  expect_error(PRE_FATE.selectDominant(mat.site.species.abund = matrix(1)), "Wrong type of data!")
  expect_error(PRE_FATE.selectDominant(mat.site.species.abund = c(1, 89, 3)), "Wrong type of data!")
  expect_error(PRE_FATE.selectDominant(mat.site.species.abund = data.frame("1")), "Wrong dimension(s) of data!", fixed = T)
  expect_error(PRE_FATE.selectDominant(mat.site.species.abund = data.frame("1","abc")), "Wrong dimension(s) of data!", fixed = T)
  expect_error(PRE_FATE.selectDominant(mat.site.species.abund = data.frame(species = "1",sites = "A")), "Wrong dimension(s) of data!", fixed = T)
  # expect_error(PRE_FATE.selectDominant(mat.site.species.abund = data.frame(species = "1",sites = "A", abundance = 3)), "Wrong dimension(s) of data!", fixed = T)
})

# ## OUTPUTS
# test_that("PRE_FATE.abundBraunBlanquet of BB values give right results", {
#   expect_equal(PRE_FATE.abundBraunBlanquet("r"), 0.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet("+"), 0.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet("1"), 3)
#   expect_equal(PRE_FATE.abundBraunBlanquet("2"), 15)
#   expect_equal(PRE_FATE.abundBraunBlanquet("3"), 37.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet("4"), 62.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet("5"), 87.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor("r")), 0.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor("+")), 0.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor("1")), 3)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor("2")), 15)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor("3")), 37.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor("4")), 62.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor("5")), 87.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(1), 3)
#   expect_equal(PRE_FATE.abundBraunBlanquet(2), 15)
#   expect_equal(PRE_FATE.abundBraunBlanquet(3), 37.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(4), 62.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(5), 87.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor(1)), 3)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor(2)), 15)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor(3)), 37.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor(4)), 62.5)
#   expect_equal(PRE_FATE.abundBraunBlanquet(factor(5)), 87.5)
# })
# 
# ## OUTPUTS
# test_that("PRE_FATE.abundBraunBlanquet of none BB values give NA", {
#   expect_equal(PRE_FATE.abundBraunBlanquet(-1), as.numeric(NA))
#   expect_equal(PRE_FATE.abundBraunBlanquet(6), as.numeric(NA))
#   expect_equal(PRE_FATE.abundBraunBlanquet(19856394), as.numeric(NA))
#   expect_equal(PRE_FATE.abundBraunBlanquet("a"), as.numeric(NA))
#   expect_equal(PRE_FATE.abundBraunBlanquet("abc"), as.numeric(NA))
# })
# 
# ## OUTPUTS
# test_that("PRE_FATE.abundBraunBlanquet of missing give NA", {
#   expect_equal(PRE_FATE.abundBraunBlanquet(NA), as.numeric(NA))
#   expect_equal(PRE_FATE.abundBraunBlanquet("NA"), as.numeric(NA))
# })
# 
# ## OUTPUTS
# test_that("PRE_FATE.abundBraunBlanquet does not modify length", {
#   expect_equal(length(PRE_FATE.abundBraunBlanquet(NA)), 1)
#   expect_equal(length(PRE_FATE.abundBraunBlanquet("NA")), 1)
#   expect_equal(length(PRE_FATE.abundBraunBlanquet("1")), 1)
#   expect_equal(length(PRE_FATE.abundBraunBlanquet(c("1", NA))), 2)
#   expect_equal(length(PRE_FATE.abundBraunBlanquet(c("1", "NA"))), 2)
#   expect_equal(length(PRE_FATE.abundBraunBlanquet(c(NA, NA))), 2)
#   expect_equal(length(PRE_FATE.abundBraunBlanquet(c(12, -789))), 2)
# })
# 
# ## OUTPUTS
# test_that("PRE_FATE.abundBraunBlanquet gives numeric output", {
#   expect_output(str(PRE_FATE.abundBraunBlanquet(NA)), "num")
#   expect_output(str(PRE_FATE.abundBraunBlanquet(1)), "num")
#   expect_output(str(PRE_FATE.abundBraunBlanquet("1")), "num")
#   expect_output(str(PRE_FATE.abundBraunBlanquet(c(1, NA))), "num")
# })
# 
# 
